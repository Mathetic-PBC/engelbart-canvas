// The SVG kind icons the design defines (Goal Canvas.dc.html lines 395–402) as React components,
// plus the KIND map keyed by a row's kind (model/kind.js: its tags first, then its type).

import { kindKey, kindLabel } from '../model/kind.js';

export const GH = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="currentColor" aria-hidden="true">
    <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z" />
  </svg>
);

export const PDF = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" aria-hidden="true">
    <path d="M3.5 1.5h6l3 3v10h-9z" />
    <path d="M9.5 1.5v3h3" />
  </svg>
);

export const LAYERS = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" aria-hidden="true">
    <path d="M8 2.5 14 5.5 8 8.5 2 5.5z" />
    <path d="M2 8.5l6 3 6-3" />
    <path d="M2 11.5l6 3 6-3" />
  </svg>
);

export const FOLDER = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" aria-hidden="true">
    <path d="M1.5 4a1 1 0 0 1 1-1h3.3l1.5 1.8h6.2a1 1 0 0 1 1 1V12a1 1 0 0 1-1 1h-11a1 1 0 0 1-1-1z" />
  </svg>
);

export const CODE = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" aria-hidden="true">
    <path d="M5.5 4.5 2 8l3.5 3.5M10.5 4.5 14 8l-3.5 3.5" />
  </svg>
);

export const WS = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" aria-hidden="true">
    <rect x={1.5} y={1.5} width={4.5} height={4.5} rx={1} />
    <rect x={8} y={1.5} width={6.5} height={4.5} rx={1} />
    <rect x={1.5} y={8} width={6.5} height={6.5} rx={1} />
    <rect x={10} y={8} width={4.5} height={4.5} rx={1} />
  </svg>
);

// A sheet with its corner turned down and three lines (Hudson's reference drawing, 2026-09-21).
export const NOTE = () => (
  <svg viewBox="0 0 16 16" width="1em" height="1em" fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" aria-hidden="true">
    <path d="M5 1.5h4.5L13 5v7.5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-9a2 2 0 0 1 2-2z" />
    <path d="M9.5 1.5v2A1.5 1.5 0 0 0 11 5h2" />
    <path d="M5.5 7.75h5M5.5 10h5M5.5 12.25h5" />
  </svg>
);

// A restrained provider mark for Google Docs titles in the shared Documents group.
export const GOOGLE_DOCS = () => (
  <svg viewBox="0 0 16 16" width={14} height={14} fill="none" stroke="currentColor" strokeWidth={1.3} strokeLinejoin="round" aria-hidden="true">
    <path d="M3 1.5h6.5L13 5v9.5H3zM9.5 1.5V5H13" />
    <path d="M5.5 7.5h5M5.5 9.75h5M5.5 12h3.5" />
  </svg>
);

/*!
 * Lucide icons (SquareDashedMousePointer, Circle, Square), as used by Engelbart Web.
 * ISC License
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part
 * of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
export const ANNOTATE = () => (
  <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z" />
    <path d="M5 3a2 2 0 0 0-2 2M19 3a2 2 0 0 1 2 2M5 21a2 2 0 0 1-2-2M9 3h1M9 21h2M14 3h1M3 9v1M21 9v2M3 14v1" />
  </svg>
);
export const RECORD = () => <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden="true"><circle cx={12} cy={12} r={10} /></svg>;
export const STOP_RECORDING = () => <svg width={14} height={14} viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth={2} strokeLinejoin="round" aria-hidden="true"><rect width={18} height={18} x={3} y={3} rx={2} /></svg>;

export const SEARCH = () => (
  <svg viewBox="0 0 16 16" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" aria-hidden="true">
    <circle cx={6.75} cy={6.75} r={4.5} />
    <path d="M10.25 10.25 14 14" />
  </svg>
);

// Bart: two speech bubbles, one answering the other (Add - Mention.dc.html, 2026-09-22).
export const CHAT = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" aria-hidden="true">
    <path d="M3 2.5h6.5a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H6.5L4 11.5v-2H3a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2z" />
    <path d="M12.5 5.5h.5a2 2 0 0 1 2 2v2.5a2 2 0 0 1-2 2h-.5v2l-2.5-2H7.5" />
  </svg>
);

export const LEAF = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" aria-hidden="true">
    <path d="M3.5 11.5C.5 5.5 6 2 14 2c0 8-3.5 13.5-9.5 10.5" />
    <path d="M2 14 10.5 5.5" />
  </svg>
);

// Overleaf mark from the supplied engelbart-icons.jsx (Simple Icons).
// Brand reference: https://www.overleaf.com/for/partners/logos
export const OVERLEAF = ({ size = 12 }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="currentColor" aria-hidden="true">
    <path d="M22.3515.7484C19.1109-.5101 7.365-.982 7.3452 6.0266c-3.4272 2.194-5.6967 5.768-5.6967 9.598a8.373 8.373 0 0 0 13.1225 6.898 8.373 8.373 0 0 0-1.7668-14.7194c-.6062-.2339-1.9234-.6481-2.9753-.559-1.5007.9544-3.3308 2.9155-4.1949 4.8693 2.5894-3.082 7.5046-2.425 9.1937 1.2287 1.6892 3.6538-.9944 7.8237-5.0198 7.7998a5.4995 5.4995 0 0 1-4.1949-1.9328c-1.485-1.7483-1.8678-3.6444-1.5615-5.4975 1.057-6.4947 8.759-10.1894 14.486-11.6094-1.8677.989-5.2373 2.6134-7.5948 4.3837C18.015 9.1382 19.1308 3.345 22.3515.7484z" />
  </svg>
);

// Generic website glyph, also used when a Stage tab has no usable favicon.
export const GLOBE = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" aria-hidden="true">
    <path d="M8 1.75a6.25 6.25 0 1 1 0 12.5 6.25 6.25 0 0 1 0-12.5z" />
    <path d="M1.75 8h12.5" />
    <path d="M8 1.75c1.8 1.7 2.7 3.8 2.7 6.25S9.8 12.55 8 14.25" />
    <path d="M8 1.75C6.2 3.45 5.3 5.55 5.3 8s.9 4.55 2.7 6.25" />
  </svg>
);

export const IMAGE = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" aria-hidden="true">
    <rect x={1.5} y={2.5} width={13} height={11} rx={1.2} />
    <circle cx={5.5} cy={6} r={1.25} />
    <path d="M14.5 10.5 11 7l-4.5 4.5L4.5 9.5 1.5 12.5" />
  </svg>
);

// A task: a clipboard with a check on it (Add - Mention.dc.html, 2026-09-22).
export const TASK = () => (
  <svg viewBox="0 0 16 16" width={12} height={12} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" aria-hidden="true">
    <path d="M5.75 3H5a2 2 0 0 0-2 2v7.5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-.75" />
    <path d="M6.75 1.75h2.5a1 1 0 0 1 1 1v.5a1 1 0 0 1-1 1h-2.5a1 1 0 0 1-1-1v-.5a1 1 0 0 1 1-1z" />
    <path d="M6.25 9.25l1.25 1.25 2.5-2.5" />
  </svg>
);

/** Kind → glyph (React node or Unicode string) and the kind's name, keyed by `kindKey(row)`. */
export const KIND = {
  note: { glyph: <NOTE />, label: 'note' },
  md: { glyph: <NOTE />, label: 'md' },
  docx: { glyph: <NOTE />, label: 'docx' },
  pdf: { glyph: <PDF />, label: 'pdf' },
  git: { glyph: <GH />, label: 'git repo' },
  folder: { glyph: <FOLDER />, label: 'folder' },
  website: { glyph: <GLOBE />, label: 'link' },
  html: { glyph: <CODE />, label: 'html' },
  data: { glyph: <LAYERS />, label: 'data file' },
  chat: { glyph: <CHAT />, label: 'chat', fixed: true },
  overleaf: { glyph: <OVERLEAF />, label: 'Overleaf', fixed: true },
  literature: { glyph: <LAYERS />, label: 'Literature', fixed: true },
  'google-docs': { glyph: <GOOGLE_DOCS />, label: 'Google Docs', fixed: true },
  task: { glyph: <TASK />, label: 'task', fixed: true },
  workspace: { glyph: <WS />, label: 'workspace', fixed: true },
  image: { glyph: <IMAGE />, label: 'image' },
};

/** A row's glyph, and the words beside it: a library row says its type then its tags ("pdf · paper"); the editor's own items keep their name. */
export function kindOf(item) {
  const kind = KIND[kindKey(item)] || KIND.note;
  return kind.fixed || !item || !item.type ? kind : { glyph: kind.glyph, label: kindLabel(item) };
}

// The design draws a note at 15px, a globe at 14 and every other kind at 12, centred in a box of 16 (18 in a list):
// the workspace sidebar's rows and search, and the @ menu (Canvas.dc.html, Add - Mention.dc.html `icon`).
const GLYPH_SIZE = { note: 15, md: 15, website: 14 };
export function KindGlyph({ item, kind: key = null, box = 16, size = null, color = '#171717' }) {
  const name = key || (item.type === 'workspace' || item.type === 'child' ? 'workspace' : kindKey(item));
  const kind = KIND[name] || kindOf(item || {});
  const glyphSize = size ?? (GLYPH_SIZE[name] || 12);
  return (
    <span style={{ flex: 'none', width: box, height: box, display: 'flex', alignItems: 'center', justifyContent: 'center', color }}>
      <span className="glyph-fit" style={{ display: 'flex', width: glyphSize, height: glyphSize }}>{kind.glyph}</span>
    </span>
  );
}
