'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const db = require('../src/main/store/db.cjs');
const { ensureHome } = require('../src/main/store/home.cjs');
const projects = require('../src/main/store/projects.cjs');
const { migrateProjectDir } = require('../src/main/store/migrate.cjs');

const homeDir = fs.mkdtempSync(path.join(os.tmpdir(), 'engelbart-projects-'));
const layout = ensureHome(homeDir);
let ctx;

test.before(async () => {
  ctx = { homeDir, root: layout.root, dataRoot: layout.testRoot, libraryDb: await db.openLibraryDb(layout.testRoot) };
});
test.after(async () => {
  await db.closeAll();
});

test('projects: create, list, rename moves the directory and rewrites note paths', async () => {
  const created = await projects.createProject(ctx, 'Thesis/2026');
  assert.equal(created.name, 'Thesis-2026');
  assert.equal(created.slug, 'thesis-2026');
  assert.equal(created.directory, null);
  assert.ok(fs.statSync(path.join(layout.testRoot, 'thesis-2026', 'notes.pglite')).isDirectory());
  const note = await projects.createNote(ctx, created.id, { name: 'First' });
  const renamed = await projects.renameProject(ctx, created.id, 'Dissertation');
  assert.equal(renamed.slug, 'dissertation');
  assert.equal((await ctx.libraryDb.get(note.id)).path, path.join(layout.testRoot, 'dissertation', 'First.md'));
  assert.ok((await projects.listProjects(ctx)).some((project) => project.id === created.id && project.workspaceCount === 0));
});

test('a custom project path keeps its directory through renames', async () => {
  const created = await projects.createProject(ctx, { name: 'Reading Group', path: 'rg-2026' });
  assert.equal(created.slug, 'rg-2026');
  assert.equal((await projects.renameProject(ctx, created.id, 'Reading Circle')).slug, 'rg-2026');
});

test('the optional initial repository is validated; the legacy directory field remains readable for migration', async () => {
  const code = fs.mkdtempSync(path.join(os.tmpdir(), 'engelbart-code-'));
  require('node:child_process').execFileSync('git', ['init', '-q', code]);
  const created = await projects.createProject(ctx, { name: 'With Code', directory: code });
  assert.equal(created.directory, null);
  const metadata = JSON.parse(fs.readFileSync(path.join(created.dir, 'project.json'), 'utf8'));
  assert.equal(metadata.repositories[metadata.defaultRepoId].location, fs.realpathSync(code));
  const bare = await projects.createProject(ctx, 'No Code Yet');
  assert.equal(bare.directory, null);
  await assert.rejects(projects.setProjectDirectory(ctx, bare.id, 'relative/path'), /absolute/);
  await assert.rejects(projects.setProjectDirectory(ctx, bare.id, path.join(code, 'missing')), /does not exist/);
  assert.equal((await projects.setProjectDirectory(ctx, bare.id, code)).directory, code);
  assert.equal((await projects.loadProject(ctx, bare.id)).project.directory, code);
  fs.rmSync(code, { recursive: true });
  const gone = (await projects.loadProject(ctx, bare.id)).project;
  assert.deepEqual([gone.directory, gone.directoryMissing], [null, code], 'a directory that vanished counts as not chosen, and is named');
});

test('createProjectWithWelcome makes a first workspace and a Welcome! note in its context', async () => {
  const made = await projects.createProjectWithWelcome(ctx, { name: 'Welcome Test' });
  const tree = await projects.loadProject(ctx, made.project.id);
  assert.equal(tree.workspaces.length, 1);
  assert.equal(tree.workspaces[0].name, 'Getting started');
  assert.deepEqual(tree.workspaces[0].context, [made.noteId]);
  assert.equal(tree.notes[0].workspaceId, made.workspaceId);
  assert.ok(fs.existsSync(path.join(made.project.dir, 'Getting started', 'workspace.md')));
  assert.ok(fs.existsSync(path.join(made.project.dir, 'Welcome!.md')));
});

test('workspaces nest to any depth; docs, context and renames work at every level', async () => {
  const project = await projects.createProject(ctx, 'Nesting');
  const top = await projects.createWorkspace(ctx, project.id, { name: 'User Interface' });
  const child = await projects.createWorkspace(ctx, project.id, { name: 'Terminal', parentId: top.id });
  const grandchild = await projects.createWorkspace(ctx, project.id, { name: 'History', parentId: child.id });
  assert.ok(fs.existsSync(path.join(project.dir, 'User Interface', 'Terminal', 'History', 'meta.json')));
  assert.ok(fs.existsSync(path.join(project.dir, 'User Interface', 'Terminal', 'History', 'workspace.md')));

  await projects.writeDoc(ctx, project.id, { kind: 'workspace', workspaceId: grandchild.id }, '# deep\n');
  assert.equal(await projects.readDoc(ctx, project.id, { kind: 'workspace', workspaceId: grandchild.id }), '# deep\n');
  assert.equal((await projects.setWorkspaceStatus(ctx, project.id, child.id, 'progress')).status, 'progress');
  assert.equal((await projects.renameWorkspace(ctx, project.id, child.id, 'Terminal')).status, 'progress', 'local workspace status remains independent of Build state');
  const grandchildMeta = path.join(project.dir, 'User Interface', 'Terminal', 'History', 'meta.json');
  const withoutStatus = JSON.parse(fs.readFileSync(grandchildMeta, 'utf8'));
  delete withoutStatus.status;
  fs.writeFileSync(grandchildMeta, JSON.stringify(withoutStatus));
  assert.equal(projects.findWorkspace(ctx, project.id, grandchild.id).workspace.status, 'open', 'Hudson-era records without a status still load');
  const note = await projects.createNote(ctx, project.id, { name: 'Reading', workspaceId: grandchild.id });
  assert.ok(fs.existsSync(path.join(project.dir, 'Reading.md')), 'notes stay flat in the project');
  assert.deepEqual((await projects.setWorkspaceContext(ctx, project.id, grandchild.id, [note.id])).context, [note.id]);

  const renamed = await projects.renameWorkspace(ctx, project.id, child.id, 'Shell');
  assert.equal(renamed.name, 'Shell');
  assert.ok(fs.existsSync(path.join(project.dir, 'User Interface', 'Shell', 'History', 'workspace.md')), 'children travel with a renamed parent');
  assert.equal((await projects.createWorkspace(ctx, project.id, { name: 'assets' })).name, 'assets workspace');

  const tree = await projects.loadProject(ctx, project.id);
  const ui = tree.workspaces.find((workspace) => workspace.id === top.id);
  assert.equal(ui.children[0].name, 'Shell');
  assert.equal(ui.children[0].children[0].id, grandchild.id);
  assert.equal((await projects.listProjects(ctx)).find((candidate) => candidate.id === project.id).workspaceCount, 4);
  await assert.rejects(projects.createWorkspace(ctx, project.id, { name: 'x', parentId: '00000000-0000-4000-8000-000000000000' }), /Unknown workspace/);
});

test('workspace context is a flat list: folders sent by an old client are flattened, bad entries rejected', async () => {
  const project = await projects.createProject(ctx, 'Folders');
  const workspace = await projects.createWorkspace(ctx, project.id, { name: 'W' });
  const note = await projects.createNote(ctx, project.id, { name: 'N', workspaceId: workspace.id });
  const other = await projects.createNote(ctx, project.id, { name: 'O', workspaceId: workspace.id });
  const folder = { id: '11111111-1111-4111-8111-111111111111', name: 'Reading', children: [note.id] };
  assert.deepEqual((await projects.setWorkspaceContext(ctx, project.id, workspace.id, [folder, other.id, note.id])).context, [note.id, other.id]);
  await assert.rejects(projects.setWorkspaceContext(ctx, project.id, workspace.id, [42]), /id or a folder/);
});

test('deleting a workspace removes its subtree and saved views, preserving notes, library items and other workspaces', async () => {
  const project = await projects.createProject(ctx, 'Delete subtree');
  const top = await projects.createWorkspace(ctx, project.id, { name: 'Parent' });
  const child = await projects.createWorkspace(ctx, project.id, { name: 'Child', parentId: top.id });
  const grandchild = await projects.createWorkspace(ctx, project.id, { name: 'Grandchild', parentId: child.id });
  const sibling = await projects.createWorkspace(ctx, project.id, { name: 'Keep' });
  const other = await projects.createProject(ctx, 'Deletion elsewhere');
  const note = await projects.createNote(ctx, project.id, { name: 'Kept note', workspaceId: child.id, text: 'Shared content' });
  await projects.setWorkspaceContext(ctx, project.id, child.id, [note.id]);
  await projects.writeDoc(ctx, project.id, { kind: 'workspace', workspaceId: grandchild.id }, 'Recoverable content');
  for (const workspace of [top, child, grandchild, sibling]) projects.writeView(ctx, project.id, workspace.id, { active: note.id, tabs: [{ id: note.id, title: note.name }] });
  projects.writeView(ctx, other.id, top.id, { active: 'ws' });
  projects.writeLastOpen(ctx, { projectId: project.id, workspaceId: grandchild.id });

  const deletion = await projects.deleteWorkspace(ctx, project.id, top.id);
  assert.deepEqual(deletion.deletedIds, [top.id, child.id, grandchild.id]);
  assert.equal(deletion.nextWorkspaceId, sibling.id);
  assert.ok(fs.existsSync(deletion.trashPath));
  const tree = await projects.loadProject(ctx, project.id);
  assert.deepEqual(tree.workspaces.map((workspace) => workspace.id), [sibling.id]);
  assert.equal((await projects.listProjects(ctx)).find((row) => row.id === project.id).workspaceCount, 1);
  assert.deepEqual(Object.keys(projects.readViews(ctx, project.id)), [sibling.id]);
  assert.deepEqual(Object.keys(projects.readViews(ctx, other.id)), [top.id]);
  assert.deepEqual(projects.readLastOpen(ctx), { projectId: project.id, workspaceId: sibling.id });
  assert.equal(await projects.readDoc(ctx, project.id, { kind: 'note', id: note.id }), 'Shared content');
  assert.ok(await ctx.libraryDb.get(note.id));
  assert.ok(tree.notes.some((row) => row.id === note.id));
  assert.equal(fs.existsSync(path.join(project.dir, top.name)), false);
  assert.equal(fs.readFileSync(path.join(project.dir, '.trash', `${top.id}-${top.name}`, child.name, grandchild.name, 'workspace.md'), 'utf8'), 'Recoverable content');
  for (const workspace of [top, child, grandchild]) {
    await assert.rejects(projects.readDoc(ctx, project.id, { kind: 'workspace', workspaceId: workspace.id }), /Unknown workspace/);
  }
  await assert.rejects(projects.deleteWorkspace(ctx, project.id, top.id), /Unknown workspace/);
});

test('deleting a nested or final workspace falls back to its parent or an empty project', async () => {
  const project = await projects.createProject(ctx, 'Delete last');
  const top = await projects.createWorkspace(ctx, project.id, { name: 'Parent' });
  const child = await projects.createWorkspace(ctx, project.id, { name: 'Only child', parentId: top.id });
  projects.writeLastOpen(ctx, { projectId: project.id, workspaceId: child.id });
  assert.equal((await projects.deleteWorkspace(ctx, project.id, child.id)).nextWorkspaceId, top.id);
  assert.equal(projects.readLastOpen(ctx).workspaceId, top.id);
  assert.deepEqual((await projects.loadProject(ctx, project.id)).workspaces[0].children, []);
  assert.equal((await projects.deleteWorkspace(ctx, project.id, top.id)).nextWorkspaceId, null);
  assert.deepEqual(projects.readLastOpen(ctx), { projectId: project.id, workspaceId: null });
  assert.deepEqual((await projects.loadProject(ctx, project.id)).workspaces, []);
  assert.equal((await projects.createWorkspace(ctx, project.id, { name: 'Parent' })).name, 'Parent', 'deleted names can be reused');
});

test('workspace deletion validates project ownership and leaves an unrelated selection alone', async () => {
  const project = await projects.createProject(ctx, 'Delete ownership');
  const other = await projects.createProject(ctx, 'Other owner');
  const workspace = await projects.createWorkspace(ctx, project.id, { name: 'Owned' });
  const selected = await projects.createWorkspace(ctx, other.id, { name: 'Selected' });
  const last = projects.writeLastOpen(ctx, { projectId: other.id, workspaceId: selected.id });
  await assert.rejects(projects.deleteWorkspace(ctx, other.id, workspace.id), /Unknown workspace/);
  await assert.rejects(projects.deleteWorkspace(ctx, project.id, '../'), /workspace id is invalid/);
  assert.equal((await projects.loadProject(ctx, project.id)).workspaces[0].id, workspace.id);
  await projects.deleteWorkspace(ctx, project.id, workspace.id);
  assert.deepEqual(projects.readLastOpen(ctx), last);
  assert.equal((await projects.loadProject(ctx, other.id)).workspaces[0].id, selected.id);
});

test('pasted images: bytes land in <project>/assets, the library gets an image row, and only images are accepted', async () => {
  const project = await projects.createProject(ctx, 'Images');
  const png = Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex');
  const row = await projects.saveImage(ctx, project.id, { bytes: png, mime: 'image/png', name: 'Attachment 1' });
  assert.equal(row.type, 'image');
  assert.equal(row.project_id, project.id);
  assert.equal(row.path, path.join(project.dir, 'assets', `${row.id}.png`));
  assert.deepEqual(fs.readFileSync(row.path), png);
  const read = await projects.readImage(ctx, row.id);
  assert.equal(read.mime, 'image/png');
  assert.deepEqual(Buffer.from(read.bytes), png);
  await assert.rejects(projects.saveImage(ctx, project.id, { bytes: png, mime: 'image/svg+xml' }), /png, jpeg, gif and webp/);
  await assert.rejects(projects.saveImage(ctx, project.id, { bytes: Buffer.alloc(0), mime: 'image/png' }), /empty/);
  assert.equal((await projects.loadProject(ctx, project.id)).workspaces.length, 0, 'assets is not a workspace');
});

test('the goal/topic layout converts in place: topics become workspaces, ids and notes survive, nothing is deleted', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'engelbart-legacy-'));
  const legacyLayout = ensureHome(root);
  const legacyCtx = { homeDir: root, root: legacyLayout.root, dataRoot: legacyLayout.root, libraryDb: await db.openLibraryDb(legacyLayout.root) };
  const dir = path.join(legacyLayout.root, 'engelbart');
  const write = (file, value) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, typeof value === 'string' ? value : JSON.stringify(value)); };
  const pid = '21f92f4d-0358-4154-850a-751be41113db';
  const ui = '712e0e1d-0715-49f8-b47f-ed08b8cb3c9b';
  const other = '69ee72b1-7963-4f83-8a7b-05d4a9e61d24';
  write(path.join(dir, 'project.json'), { id: pid, name: 'Engelbart', created: '2026-09-17T03:46:45.017Z' });
  write(path.join(dir, 'First steps', 'meta.json'), { id: 'cc48c423-574b-4bff-85f6-53b2bc44b5ac', box: 'current', created: '2026-09-17T03:46:45.503Z' });
  write(path.join(dir, 'First steps', 'future.md'), '- later\n');
  const held = ['aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb'];
  write(path.join(dir, 'First steps', 'User Interface', 'meta.json'), { id: ui, status: 'open', context: [{ id: 'cccccccc-cccc-4ccc-8ccc-cccccccccccc', name: 'Reading', children: [held[0]] }, held[1]], created: '2026-09-17T03:47:32.035Z' });
  write(path.join(dir, 'First steps', 'User Interface', 'workspace.md'), 'ui notes\n');
  write(path.join(dir, 'Second', 'meta.json'), { id: 'dd48c423-574b-4bff-85f6-53b2bc44b5ac', box: 'past', created: '2026-09-17T04:00:00.000Z' });
  write(path.join(dir, 'Second', 'User Interface', 'meta.json'), { id: other, status: 'done', context: [], created: '2026-09-17T04:01:00.000Z' });
  write(path.join(dir, 'Second', 'User Interface', 'workspace.md'), 'same name, other goal\n');

  const preview = migrateProjectDir(dir, { dryRun: true });
  assert.deepEqual(preview.moved.map((move) => move.to), ['User Interface', 'User Interface 2']);
  assert.ok(fs.existsSync(path.join(dir, 'First steps', 'User Interface', 'workspace.md')), 'a dry run moves nothing');

  const tree = await projects.loadProject(legacyCtx, pid); // the store converts on first touch
  assert.deepEqual(tree.workspaces.map((workspace) => [workspace.id, workspace.name]), [[ui, 'User Interface'], [other, 'User Interface 2']]);
  assert.equal(await projects.readDoc(legacyCtx, pid, { kind: 'workspace', workspaceId: ui }), 'ui notes\n');
  assert.deepEqual(tree.workspaces[0].context, held, 'what the context folder held stays, flat and in order');
  assert.deepEqual(JSON.parse(fs.readFileSync(path.join(dir, 'User Interface', 'meta.json'), 'utf8')).context, held);
  assert.equal(fs.readFileSync(path.join(dir, '.legacy', 'First steps', 'future.md'), 'utf8'), '- later\n');
  const backups = fs.readdirSync(path.join(legacyLayout.root, '.backups'));
  assert.equal(backups.length, 1);
  assert.equal(fs.readFileSync(path.join(legacyLayout.root, '.backups', backups[0], 'First steps', 'User Interface', 'workspace.md'), 'utf8'), 'ui notes\n');
  assert.equal(migrateProjectDir(dir), null, 'already converted');
  assert.equal((await projects.listProjects(legacyCtx)).length, 1, 'dot directories are not projects');
});

test('last-open state: stored per data root, stale ids become null, files from the topic era still read', async () => {
  const project = await projects.createProject(ctx, 'Reopen');
  const written = projects.writeLastOpen(ctx, { projectId: project.id, workspaceId: 'nope', extra: 1 });
  assert.deepEqual(written, { projectId: project.id, workspaceId: null });
  assert.deepEqual(projects.readLastOpen(ctx), written);
  fs.writeFileSync(path.join(layout.testRoot, 'state.json'), JSON.stringify({ projectId: project.id, goalId: project.id, topicId: project.id }));
  assert.deepEqual(projects.readLastOpen(ctx), { projectId: project.id, workspaceId: project.id });
});

test('views: each workspace keeps its tabs, the document in front and its scroll positions; last-open keeps them (2026-09-22)', async () => {
  const project = await projects.createProject(ctx, 'Views');
  const other = await projects.createProject(ctx, 'Views elsewhere');
  const ws = '11111111-1111-4111-8111-111111111111', ws2 = '22222222-2222-4222-8222-222222222222';
  const note = '33333333-3333-4333-8333-333333333333', gone = '44444444-4444-4444-8444-444444444444';
  projects.writeLastOpen(ctx, { projectId: project.id, workspaceId: ws });
  const saved = projects.writeView(ctx, project.id, ws, {
    active: note,
    tabs: [{ id: note, title: 'Middle Canvas' }, { id: note, title: 'twice' }, { id: 'not-an-id', title: 'x' }],
    positions: { [`ws:${ws}`]: { top: 120.4, line: 7, offset: 12.6, hash: 'abc12' }, [`note:${note}`]: { top: 900 }, 'bad:key': { top: 1 }, [`note:${gone}`]: { top: 'x' } },
    extra: true,
  });
  assert.deepEqual(saved, { active: note, tabs: [{ id: note, title: 'Middle Canvas' }], positions: { [`ws:${ws}`]: { top: 120, line: 7, offset: 13, hash: 'abc12' }, [`note:${note}`]: { top: 900 } } });
  projects.writeView(ctx, project.id, ws2, { active: gone, tabs: [] });
  projects.writeView(ctx, other.id, ws, { active: 'ws', tabs: [], positions: {} });
  const views = projects.readViews(ctx, project.id);
  assert.deepEqual(views[ws], saved);
  assert.deepEqual(views[ws2], { active: 'ws', tabs: [], positions: {} }, 'a document in front that is not one of its tabs falls back to the workspace');
  assert.deepEqual(Object.keys(projects.readViews(ctx, other.id)), [ws], 'views are per project');
  assert.deepEqual(projects.readLastOpen(ctx), { projectId: project.id, workspaceId: ws }, 'saving a view keeps where the app reopens');
  projects.writeLastOpen(ctx, { projectId: other.id, workspaceId: ws2 });
  assert.deepEqual(projects.readViews(ctx, project.id)[ws], saved, 'moving to another workspace keeps every view');
  assert.deepEqual(projects.readViews(ctx, 'nope'), {});
  assert.throws(() => projects.writeView(ctx, project.id, 'nope', {}), /workspace id/);
  assert.throws(() => projects.writeView(ctx, project.id, ws, null), /invalid/);
  // Another workspace's document open as a tab keeps its kind; any other kind is dropped (2026-09-23).
  const withWs = projects.writeView(ctx, project.id, ws, { active: ws2, tabs: [{ id: note, title: 'n', kind: 'note?' }, { id: ws2, title: 'Child', kind: 'workspace' }], positions: {} });
  assert.deepEqual(withWs.tabs, [{ id: note, title: 'n' }, { id: ws2, title: 'Child', kind: 'workspace' }]);
  assert.equal(withWs.active, ws2);
  const file = '2026-09-28T10-11-12Z', id = `archive:${file}`;
  const archived = projects.writeView(ctx, project.id, ws, { active: id, tabs: [{ id, title: 'Archived draft' }, { id: 'archive:../../other', title: 'unsafe' }], positions: { [`archive:${ws}:${file}`]: { top: 230 } } });
  assert.deepEqual(archived, { active: id, tabs: [{ id, title: 'Archived draft' }], positions: { [`archive:${ws}:${file}`]: { top: 230 } } });
  assert.deepEqual(projects.readViews(ctx, project.id)[ws], archived);
});

test('where to next: state.json keeps the last three workspaces written in and the agents, beside the views; stale rows are not read (2026-09-22)', async () => {
  const project = await projects.createProject(ctx, 'Next place');
  const a = await projects.createWorkspace(ctx, project.id, { name: 'Alpha' });
  const b = await projects.createWorkspace(ctx, project.id, { name: 'Beta' });
  const c = await projects.createWorkspace(ctx, project.id, { name: 'Gamma', parentId: b.id });
  const d = await projects.createWorkspace(ctx, project.id, { name: 'Delta' });
  projects.writeLastOpen(ctx, { projectId: project.id, workspaceId: a.id });
  projects.writeView(ctx, project.id, a.id, { active: 'ws', tabs: [], positions: {} });

  for (const workspace of [a, b, c, a, d]) projects.recordEdit(ctx, project.id, workspace.id);
  let nav = projects.readNav(ctx);
  assert.deepEqual(nav.recent.map((entry) => entry.name), ['Delta', 'Alpha', 'Gamma', 'Beta'], 'newest first, once each; every one written in the last thirty minutes');
  assert.deepEqual([nav.recent[2].path, nav.recent[2].projectName], ['Beta/Gamma', 'Next place']);
  assert.ok(nav.recent.every((entry) => !Number.isNaN(Date.parse(entry.at))));
  assert.throws(() => projects.recordEdit(ctx, project.id, '99999999-9999-4999-8999-999999999999'), /Unknown workspace/);

  projects.agentStarted(ctx, { id: 'ask-1', kind: 'bart', projectId: project.id, workspaceId: b.id, doc: { kind: 'workspace', workspaceId: b.id } });
  projects.agentStarted(ctx, { id: 'ask-2', kind: 'bart', projectId: project.id, workspaceId: c.id, doc: { kind: 'note', id: 'not-an-id' } });
  nav = projects.readNav(ctx);
  assert.deepEqual(nav.agents.map((agent) => [agent.id, agent.status, agent.name]), [['ask-1', 'running', 'Beta'], ['ask-2', 'running', 'Gamma']]);
  assert.deepEqual(nav.agents[1].doc, null, 'a document reference that is not one is dropped, the agent kept');
  projects.agentFinished(ctx, 'ask-1');
  projects.agentStopped(ctx, 'ask-2');
  nav = projects.readNav(ctx);
  assert.deepEqual(nav.agents.map((agent) => [agent.id, agent.status]), [['ask-1', 'waiting']], 'a stopped agent leaves nothing waiting');
  assert.ok(nav.agents[0].finished);
  assert.equal(projects.seenAgents(ctx, project.id, a.id), 0, 'looking elsewhere sees nothing');
  assert.equal(projects.seenAgents(ctx, project.id, b.id), 1);
  assert.deepEqual(projects.readNav(ctx).agents, []);

  const file = path.join(layout.testRoot, 'state.json');
  const state = JSON.parse(fs.readFileSync(file, 'utf8'));
  assert.deepEqual([state.projectId, state.workspaceId], [project.id, a.id], 'where the app reopens is kept');
  assert.ok(state.views[project.id][a.id], 'and every view');
  assert.equal(state.recent.length, 4);
  projects.writeView(ctx, project.id, b.id, { active: 'ws', tabs: [], positions: {} });
  projects.writeLastOpen(ctx, { projectId: project.id, workspaceId: b.id });
  assert.equal(JSON.parse(fs.readFileSync(file, 'utf8')).recent.length, 4, 'saving a view or where the app reopens keeps the recent ones');

  // A running row written by an earlier run of the app (its id not live here), a waiting one whose workspace is gone, junk.
  fs.writeFileSync(file, JSON.stringify({ ...state, agents: [
    { id: 'old-run', kind: 'bart', projectId: project.id, workspaceId: a.id, status: 'running', started: '2026-09-21T10:00:00.000Z' },
    { id: 'gone', kind: 'bart', projectId: project.id, workspaceId: '99999999-9999-4999-8999-999999999999', status: 'waiting', finished: '2026-09-21T10:00:00.000Z' },
    { id: 'kept', kind: 'bart', projectId: project.id, workspaceId: d.id, status: 'waiting', finished: '2026-09-21T10:00:00.000Z' },
    { id: 'odd', kind: 'robot', projectId: project.id, workspaceId: d.id, status: 'waiting' },
    'nonsense',
  ], recent: [...state.recent, { projectId: project.id, workspaceId: 'nope', at: 'x' }] }));
  nav = projects.readNav(ctx);
  assert.deepEqual(nav.agents.map((agent) => agent.id), ['kept']);
  assert.equal(nav.recent.length, 4);

  // Older than thirty minutes: only the newest three stay, however many there were (2026-09-23).
  const old = (minutes) => new Date(Date.now() - minutes * 60000).toISOString();
  fs.writeFileSync(file, JSON.stringify({ ...state, agents: [], recent: [
    { projectId: project.id, workspaceId: d.id, at: old(5) },
    { projectId: project.id, workspaceId: a.id, at: old(40) },
    { projectId: project.id, workspaceId: c.id, at: old(50) },
    { projectId: project.id, workspaceId: b.id, at: old(60) },
  ] }));
  assert.deepEqual(projects.readNav(ctx).recent.map((entry) => entry.name), ['Delta', 'Alpha', 'Gamma'], 'the last three when fewer than three are fresh');
  fs.writeFileSync(file, JSON.stringify({ ...state, agents: [], recent: [
    { projectId: project.id, workspaceId: d.id, at: old(1) },
    { projectId: project.id, workspaceId: a.id, at: old(2) },
    { projectId: project.id, workspaceId: c.id, at: old(3) },
    { projectId: project.id, workspaceId: b.id, at: old(29) },
  ] }));
  assert.equal(projects.readNav(ctx).recent.length, 4, 'all four when all four are fresh');
  projects.recordEdit(ctx, project.id, a.id);
  assert.deepEqual(projects.readNav(ctx).recent.map((entry) => entry.name), ['Alpha', 'Delta', 'Gamma', 'Beta']);
});

test('read-text-file: project-relative, ~/ and absolute paths inside the home directory only', async () => {
  const project = await projects.createProject(ctx, 'Browser');
  fs.writeFileSync(path.join(project.dir, 'notes.txt'), 'hello\nworld\n');
  assert.equal((await projects.readProjectTextFile(ctx, project.id, 'notes.txt')).text, 'hello\nworld\n');
  assert.equal((await projects.readProjectTextFile(ctx, project.id, './notes.txt')).kind, 'file');
  const viaHome = await projects.readProjectTextFile(ctx, project.id, `~/${path.relative(homeDir, path.join(project.dir, 'notes.txt'))}`);
  assert.equal(viaHome.text, 'hello\nworld\n');
  const dir = await projects.readProjectTextFile(ctx, project.id, project.dir);
  assert.equal(dir.kind, 'directory');
  assert.ok(dir.text.split('\n').includes('notes.txt'));
  await assert.rejects(projects.readProjectTextFile(ctx, project.id, '/etc/hosts'), /inside your home directory/);
  await assert.rejects(projects.readProjectTextFile(ctx, project.id, 'missing.txt'));
  fs.writeFileSync(path.join(project.dir, 'big.txt'), 'x'.repeat(25000));
  const big = await projects.readProjectTextFile(ctx, project.id, 'big.txt');
  assert.equal(big.text.length, 20000);
  assert.equal(big.truncated, true);
});

test('resolve-page-file: an html file by full path, or relative to the project, the engelbart folder or the code directory', async () => {
  const code = path.join(homeDir, 'code-pages');
  fs.mkdirSync(path.join(code, 'docs'), { recursive: true });
  const project = await projects.createProject(ctx, { name: 'Pages' });
  await projects.setProjectDirectory(ctx, project.id, code); // legacy relative-file compatibility
  fs.mkdirSync(path.join(project.dir, 'My Workspace'), { recursive: true });
  fs.writeFileSync(path.join(project.dir, 'My Workspace', 'report.html'), '<h1>r</h1>');
  fs.writeFileSync(path.join(project.dir, 'notes.txt'), 'text');
  fs.writeFileSync(path.join(code, 'docs', 'index.htm'), '<h1>d</h1>');
  const real = (file) => fs.realpathSync(file);
  const { pathToFileURL } = require('node:url');

  const report = real(path.join(project.dir, 'My Workspace', 'report.html'));
  const found = await projects.resolvePageFile(ctx, project.id, 'My Workspace/report.html');
  assert.deepEqual(found, { path: report, url: pathToFileURL(report).href });
  assert.equal((await projects.resolvePageFile(ctx, project.id, report)).path, report);
  assert.equal((await projects.resolvePageFile(ctx, project.id, `~/${path.relative(homeDir, report)}`)).path, report);
  assert.equal((await projects.resolvePageFile(ctx, project.id, pathToFileURL(report).href)).path, report);
  assert.equal((await projects.resolvePageFile(ctx, project.id, `${path.basename(project.dir)}/My Workspace/report.html`)).path, report); // from the engelbart folder
  assert.equal((await projects.resolvePageFile(ctx, project.id, 'docs/index.htm')).path, real(path.join(code, 'docs', 'index.htm'))); // from the code directory
  assert.equal((await projects.resolvePageFile(ctx, project.id, 'My Workspace/report.html#results?x')).url, `${pathToFileURL(report).href}#results?x`);
  fs.writeFileSync(path.join(project.dir, 'My Workspace', 'paper.pdf'), '%PDF-1.4');
  assert.equal((await projects.resolvePageFile(ctx, project.id, 'My Workspace/paper.pdf')).url, pathToFileURL(real(path.join(project.dir, 'My Workspace', 'paper.pdf'))).href); // not printed as text

  for (const not of ['notes.txt', 'missing.html', 'apple.com', 'example.com/index.html', '/etc/hosts', 'My Workspace']) {
    assert.equal(await projects.resolvePageFile(ctx, project.id, not), null, not);
  }
  fs.symlinkSync('/etc/hosts', path.join(project.dir, 'escape.html'));
  assert.equal(await projects.resolvePageFile(ctx, project.id, 'escape.html'), null);
  assert.equal((await projects.readProjectTextFile(ctx, project.id, 'notes.txt')).text, 'text');
});
