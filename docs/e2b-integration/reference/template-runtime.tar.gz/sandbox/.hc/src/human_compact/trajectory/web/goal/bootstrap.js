/* The goal page. State lives in the store, the reader's actions change it,
   and every change redraws the page from it. */

import { createStore, initialState, activeSlice } from "./store.js";
import { services } from "./services.js";
import { createActions } from "./actions.js";
import { mount } from "./dom.js";
import { fitLayout } from "./layout.js";

export function startWorkspace(renderPage) {
const host = document.getElementById("app");
const store = createStore(initialState());
const actions = createActions(store, services);

let feedMark = "";

function draw(state) {
  // DOM morphing removes measured inline heights before fitLayout restores
  // them. Preserve scrolling across the entire update, not just measurement.
  const todos = host.querySelector(".todos");
  const scrollTop = todos?.scrollTop;
  mount(host, renderPage(state, actions));
  fitLayout(host);
  if (todos && todos === host.querySelector(".todos")) todos.scrollTop = scrollTop;
  document.title = state.goal ? `Engelbart · ${state.goal.title}` : "Engelbart";
  // The feed follows its newest message, and opens on it; a reader who has
  // scrolled up to read is left where they are until one arrives.
  const feed = host.querySelector("[data-feed]");
  const mark = feed ? `${state.activeId}:${activeSlice(state).chat.length}` : "";
  if (feed && mark !== feedMark) feed.scrollTop = feed.scrollHeight;
  feedMark = mark;
  if (state.renamingSubgoal) {
    const input = host.querySelector('[data-key="sub-rename-input"]');
    if (input && document.activeElement !== input) { input.focus(); input.select(); }
  }
  if (state.addingSubgoal) {
    const input = host.querySelector('[data-key="sub-add-input"]');
    if (input && document.activeElement !== input) input.focus();
  }
  const modal = host.querySelector('.project-analysis-modal');
  if (modal && !modal.contains(document.activeElement)) {
    const input = modal.querySelector('input:not(:disabled),button:not(:disabled)');
    if (input) input.focus();
  }
  // A workspace with no goal opens on the line that asks for one.
  if (state.status === "ready" && state.empty && !state.newProject) {
    const input = host.querySelector("#goal-input");
    if (input && document.activeElement !== input) input.focus();
  }
}

new ResizeObserver(() => fitLayout(host)).observe(host);
window.addEventListener("resize", () => fitLayout(host));
store.subscribe(draw);
draw(store.get());
actions.boot();

// On the capture phase: by the time a click has bubbled up, the row it
// landed on may have been redrawn out of the tree and no longer counts as
// inside the menu.
document.addEventListener("click", (event) => {
  if (!event.target.closest("[data-account]")) actions.closeAccount();
  if (!event.target.closest("[data-api]")) actions.closeApi();
  if (!event.target.closest("[data-notifications]")) actions.closeNotifications();
}, true);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") { actions.closeAccount(); actions.closeApi(); actions.closeNotifications(); }
});

// For the console and the tests; nothing on the page reads it.
window.engelbart = { store, actions, services };

// Cross-origin preview content stays opaque; entering the frame is still a
// meaningful local interaction and never causes a model call.
window.addEventListener("blur", () => {
  setTimeout(() => {
    if (document.activeElement && document.activeElement.matches("iframe.preview-frame")) {
      actions.interaction("preview.interacted", { action: "focused" });
    }
  }, 0);
});
document.addEventListener("click", (event) => {
  const link = event.target.closest("a[data-artifact]");
  if (link) actions.interaction("artifact.opened", { artifact: link.getAttribute("data-artifact") });
}, true);

}
