# The behavior trace

What a person does in a running research artifact, what the artifact asks
over the network and of a model in return, and what visibly changes, as one
timeline per run. Three processes in the sandbox write it; the worker's
collector reads it and stores it under the run's identity.

```
browser ──bridge.js──► preview-gateway.mjs ──stdout──► worker collector ──► engelbart_trace_events
  │                          │  (network.*)                                 engelbart_model_calls
  └── application ──► model-gateway.mjs ──stdout──┘  (model.*)
        └ preload.cjs puts the call there, with the artifact unedited
```

## The line format

Every process writes one JSON object per stdout line, marked
`{"engelbart":"trace","v":1,"source":…,"kind":…,"ts":…}`, and human lines on
stderr prefixed `[model-gateway]`, `[preview-gateway]`, `[browser-bridge]`
(the bridge logs to the page's console). The collector (`lib/trace/collector.ts`)
recognises the marked lines and passes everything else through as ordinary
stdout. Identity comes from the worker: nothing in the sandbox or the
browser can claim another run's trace.

Ids that appear on lines and land in their own columns:

| id | minted by | example | meaning |
|----|-----------|---------|---------|
| `frameId` | preview gateway per served HTML document (the bridge mints one for frames it attaches to itself) | `f_3fa9c1e2b0` | which document an event happened in |
| `interactionId` | bridge, one per meaningful interaction | `i_3fa9c1e2b0_12` | the interaction a request or change belongs to |
| `requestId` | preview gateway per application request | `r_…` | one request through the gateway |
| `callId` | model gateway per model call | `mc_…` | one model call |

`correlation` says how an event was tied to an interaction: `explicit` when
the request carried the id in an `x-engelbart-interaction` header, `temporal`
when only timing associates them (a `ui.change` after an interaction; a
model call made while exactly one application request was being handled).
A temporal link is an association, not a claim of cause; with several
requests open the collector links nothing and lists the candidates.

## model-gateway.mjs

A loopback HTTP proxy the application's model client is pointed at
(`OPENAI_BASE_URL=http://127.0.0.1:43200/t/<token>/https/<host>/v1`). It
forwards each request byte for byte to the artifact's original upstream,
streams the answer back untouched, and describes the exchange from a tee:
`model.request` (model, settings, system prompt, messages, tools, response
format), `model.response` (streamed output merged, usage when the provider
sent it, timings) or `model.error`. Capture `full` keeps content, `metadata`
keeps shapes and counts. Known secret values and anything shaped like a
key are redacted before a line is written.

Carrying a request and reading one are separate decisions, made in that
order.

It carries everything. Not recognising a destination says something about
Engelbart, not about whether the application may use its network, so an
unrecognised request is relayed rather than refused. Three refusals are
left and none of them can reach a working application: a wrong token
(404), the gateway's own address (508, which is a loop and not a
request), and a host the run denied by name through
`ENGELBART_MODEL_DENY` (403, empty by default). A websocket upgrade or a
`CONNECT` cannot be carried by a proxy that tees, so it is reported as
`gateway.unsupported` and closed rather than silently broken — nothing
should redirect one here.

It reads only what something declared. Either the operator named the host
a model endpoint (`ENGELBART_MODEL_UPSTREAMS`, plus the three defaults) or
a provider module claims the request's shape — and a provider match alone
is enough, so an OpenAI-compatible host nobody configured is still
understood. Both are decided from the route before a byte of the body is
taken. Anything else is relayed with no body buffered, no stream
decompressed and no request header kept, and leaves one `gateway.relayed`
event carrying where it went, how big it was and how it went. Being able
to see a request is not a reason to store it.

## preload.cjs

How an artifact's model calls reach the gateway without the artifact being
edited. `OPENAI_BASE_URL` works when the operator can set it; this is for
the repositories where the URL is written into the source, which is most
of them.

hc launches the application with `--require=/opt/engelbart/trace/preload.cjs`
and one marker, `ENGELBART_MODEL_CAPTURE`, holding the gateway's own URL.
Neither comes from the repository: the supervisor names the preload once
in hc's own environment, a run asks for the `modelCapture` capability by
name, and hc resolves the path itself and applies it after the plan's
env, so nothing in the project can name another preload or undo this one
(`sandbox/hc/project_instrumentation.py`). Inside the process the marker
is the authorisation: with no marker the file does nothing at all.

It moves requests rather than reading them. Three hooks, because no one
of them covers Node: `http.request`/`https.request` and their `get`
twins, `globalThis.fetch`, and undici's global dispatcher — the last
installed by watching `Object.defineProperty` for undici's dispatcher
symbol, so a later `setGlobalDispatcher` is re-wrapped instead of
silently removing capture. A redirected request keeps its method, headers
and body; the original scheme and host travel in the gateway's path.
Provider decoding stays in the gateway.

What it refuses to touch: a request carrying its own TLS material (`ca`,
`cert`, `key`, `pfx`, `rejectUnauthorized`, `checkServerIdentity`), an
`Upgrade`, anything to the gateway itself, and anything to a local
address unless `ENGELBART_MODEL_CAPTURE_LOCAL` names it. It does not arm
in an Engelbart-owned process, nor in one holding `ENGELBART_TRACE_TOKEN`,
so the gateways and the agent's own traffic are never intercepted.

Failing to observe must never be failing to run, so nothing is redirected
until the gateway has answered once, per realm; a socket error to the
gateway stops redirection for the rest of the run; and calls that went
out unobserved are counted and reported rather than lost quietly. The
whole bootstrap is one `try`, and it writes nothing to the application's
stdout or stderr — a line hc reads as an app error would send the run to
the repair rung, where an agent would edit the repository.

The run says which of these happened. `capability.modelCapture` carries
`available` (armed, gateway answered), `active` (something was actually
carried, with which transports), `partial` (the pre-launch scan found
paths that declare the Next edge runtime or are Next middleware, naming
up to twenty of them — or the scan could not finish, in which case
whether anything bypasses capture is unknown), `unsupported_runtime`,
`unsupported_launcher` (bun, deno, docker, python, a shell script — named
before launch), `instrumentation_failed` or `unavailable`. A trace with
no model calls and a trace where capture was impossible are different
facts and are recorded as different facts.

What this reaches, measured rather than asserted, is in
[CAPTURE.md](CAPTURE.md): twelve runtime and launcher paths, and the list
of what is not supported.

## preview-gateway.mjs

Takes `proxy.mjs`'s place for a traced run: the same public port per
service, the same Host/Origin/Referer rewriting, the same WebSocket
pass-through. On top of that:

- every `text/html` document it serves (top page or iframe alike) gets
  `<script src="/__engelbart/recorder.js">` and then
  `<script src="/__engelbart/bridge.js" data-frame="f_…">` right after
  `<head>` (after `<html>` or the doctype when there is no head) — the
  recorder first, and only when the image carries one, so the bridge can
  test for it rather than race it; both are classic scripts, so they run in
  that order, and neither records anything of its own accord. Whether a
  recorder was there is on `frame.served`. Streamed,
  with `accept-encoding: identity` asked of the application so the document
  arrives uncompressed; a compressed document is decompressed first;
- a document whose Content-Security-Policy would refuse a same-origin
  script is served as it is and reported as `bridge.blocked` (a nonce in the
  policy is reused instead); the policy is never weakened;
- the gateway answers four paths of its own: `/__engelbart/events` takes
  the bridge's batches (checked for shape and size, rate limited, browser
  clock converted with the batch's offset), `/__engelbart/bridge.js` serves
  the bridge (`no-cache`, with an etag), `/__engelbart/recorder.js` serves
  the vendored rrweb recorder (`immutable` for a year, because it is pinned
  and identical on every sandbox built from the image, or a 404 when the
  image carries none) and `/__engelbart/health` answers with counters and
  with the origins the injected bridge will obey, which is how a workspace
  tells "it refused you" apart from "it has no picker in it";
- requests that are not assets (scripts, styles, images, fonts, the dev
  server's own traffic) become `network.request` and `network.response` or
  `network.error` lines: method, path (query stripped off it), `has_query`
  and a `query` object beside it — up to eight parameters, names cut to 32
  characters, each value kept as it is unless the name matches
  `token|key|secret|auth|password|passwd|session|sig|credential|cookie|bearer`
  or the value runs past 48 characters, when it becomes `[omitted]` —
  category (`document`, `api`, `action`, `prefetch`), status, timings,
  sizes, a header allowlist. Bodies are never read. The interaction header is forwarded to
  the application unchanged.

## bridge.js

A plain browser script. It records, as DOM facts, never as meaning:

| kind | when | what it carries |
|------|------|-----------------|
| `ui.click` | a click | target and the interactive control around it |
| `ui.submit` | a form submit | form, submitter, field names and types (never values) |
| `ui.input` | typing in a field, folded over 900 ms of quiet (or blur, or the focus moving on) | `editing`, an edit count, the target and its kind, and the value's length — never for a password field, which reports neither contents nor length |
| `ui.input` | a control's committed change | `commit`, with the selected option text, on/off, a slider, date or colour value, a file count; for text only its length |
| `ui.key` | a keydown that passes the keyboard policy | key name or class, count (repeats and quick identical presses fold), target |
| `ui.wheel` | wheeling or pinching over one thing, folded over 900 ms | target, count, axis, direction (`in`/`out` with ctrl held, which is how a browser reports a pinch), a magnitude bucket (small under 120px, medium under 600, else large), duration |
| `ui.drag` | a press, a move and a release on one thing, once the pointer has travelled 8px | target, move count, duration, a distance bucket (short under 40px, medium under 240, else long), direction, button |
| `ui.focus` | focus arriving in an embedded document | what has focus |
| `ui.route` | pushState/replaceState/popstate/hashchange | from, to, how |
| `ui.change` | the DOM went quiet (700 ms) after mutating following an interaction | mutation counts, small samples of visible text that appeared and disappeared, the smallest container, timing since the interaction. Text removed and put back in the same burst (a rerender) is counted as `rerendered`, not quoted. Mutations inside a text-entry surface are never recorded: a framework mirroring the draft into a textarea's text node would otherwise leak it |
| `frame.loaded` | the document is parsed | url with its search replaced by `?…`, the parameters beside it under the same secret-name and length rules, title, whether embedded, an inventory of surfaces (canvas, video, form, iframe, …) |
| `frame.attached` | an embedded document and its parent found each other | parent frame, selector in the parent, name, depth, whether it observes itself or its parent observes it |
| `frame.discovered` | an iframe the bridge cannot reach | selector, reason (`cross-origin`, `sandboxed`, `no-window`), source url |
| `frame.removed` | an iframe left the DOM | the child's frame id |
| `frame.record` | replay capture opened or closed | `start` with the canvas rate, or `stop` — and no `stop` when capture ended by running out of its byte budget |

Every element is described the same way: tag, id, name, type, role, visible
text (capped), aria label, title, placeholder, test id, stable classes, a CSS
selector, bounding rect, href or form action (same-origin path only, query
omitted), and the frame's route. Never coordinates alone, never a value.

Not recorded, on purpose: hover, bare pointer movement with no button
held, the path or coordinates of any gesture, printable keystrokes on any
text-entry surface, field values, and application state. Wheeling and
dragging are recorded, but only ever as the summaries above — a count, a
bucket, a direction and a duration, never a track.

DOM snapshots and canvas pixels are not on the trace either, and are not
nothing: while a recording is open the bridge drives a vendored rrweb
recorder (`recordCanvas`, 12 pictures a second, `image/webp` at 0.6, a
whole-page checkout every 30 s) and itself photographs the canvases in
same-origin child documents that the recorder's single-window manager
cannot reach. That stream leaves over the annotate channel to the
workspace, in parts, under a 32 MB budget — never through the events
endpoint, and never when no recording is open. The always-on trace
carries no snapshot, no draw call and no pixel, so what a canvas game did
is visible there only through the keys and clicks that reached it and any
DOM that changed.

### Keyboard policy

- Text-entry surfaces (inputs, textareas, contenteditable, `role=textbox`
  and friends, known editor containers): only Enter, Escape, Tab, arrows,
  Home/End/Page keys and F-keys, by name, plus Ctrl/Meta commands by name
  (`Ctrl+s`). Nothing printable, not even with Shift. A password field
  allows only Enter, Escape and Tab.
- Everywhere else (canvas, body, buttons, sliders, custom controls): control
  and navigation keys by name (`ArrowLeft`, `Space`, `Shift+Tab`), commands
  by name, and printable keys only as `[printable]` with a class (`letter`,
  `digit`, `symbol`) and a count. The character never leaves the page.
- Modifier keys alone and composition events are ignored; auto-repeat and
  identical presses within 800 ms fold into one event with a count.

### Frames

Each gateway-served document runs its own bridge and posts its own batches.
An embedded document says hello to its parent over `postMessage` (same
origin only); the parent answers with the child's selector, name and depth,
and the child reports `frame.attached`. A same-origin frame with no bridge
of its own (srcdoc, blob, about:blank) is observed from the parent under a
bridge-minted id. A frame that cannot be reached is reported once as
`frame.discovered` with the reason; what happens inside it is not recorded.

"The latest interaction" of a document includes what happens in the frames
it embeds: a bridged child posts `activity` (its interaction id and time)
to its parent, and the parent uses it for request tagging and change
attribution like one of its own. A page that logs a key press it was told
about by its game frame therefore tags that request with the press, not
with whatever the page itself was last clicked on.

### Footprint on the page

One capturing listener per event type on the document, a wrapped `fetch`
and `XMLHttpRequest` that add `x-engelbart-interaction` to same-origin
requests started within 10 s of an interaction (never to another origin, a
`no-cors` request, or the bridge's own transport; an empty URL is the
document itself, which is how Next.js posts a server action), patched
`history.pushState`/`replaceState` that also emit a route event, one
MutationObserver, and a non-enumerable `window.__engelbart` with the frame
id and the helpers the tests use. The application's own traffic and
behaviour are otherwise unchanged. Tuning rides on the script tag as
`data-config` (JSON of known keys).

Two more, and only while the workspace asks for them. The picker is one:
see **Annotate mode**. Replay capture is the other — a `record` message
starts the rrweb recorder in the document, plus an interval photographing
the canvases of same-origin frames and a queue posting parts back up the
same channel. It is started and stopped by the workspace's Record button,
independently of the picker, and it is the only one of the two that
leaves anything on the trace, as `frame.record`.

### Annotate mode

A researcher can point at an element of the running interface and write a
note about it. The picker lives in the bridge; the note does not.

The bridge only observes until it is told otherwise. The workspace turns
the picker on by posting into the preview's frame, and the bridge accepts
that message only from the window that embeds the document and only when
that window's origin is one of `config.parentOrigins`, or the older single
`config.parentOrigin`, which the gateway sets per run from
`ENGELBART_BRIDGE_CONFIG`. With neither of them the channel never opens.
It is a list because one workspace is served from more than one origin —
a dev server and a deployment — and a sandbox pinned to whichever of them
launched it refuses the other in silence. Whoever turned it on is who results go back to, so an
embedded document is told by its parent and answers its parent: a pick
made three frames down arrives at the workspace with each frame's offset
added to the rect and each frame's selector added to the path. A frame
that cannot be reached — another origin, or sandboxed without
`allow-same-origin` — is reported as unavailable rather than skipped; the
`<iframe>` element itself is still annotatable from the page around it.

While it is on:

- an overlay draws an outline around whatever the pointer is over, inside
  a **closed** shadow root on an element carrying `data-engelbart`, with
  every style set as a property rather than through a `<style>` element or
  a style attribute, so a strict `style-src` cannot silently blank it. The
  page underneath is any colour at all, so the outline is three bands — a
  white hairline, the accent, a soft halo — over a wash of the accent, and
  a chip names the element the way a browser's own inspector does: tag
  first, then what it says, then its size, because with nested elements
  whose edges nearly coincide the text alone does not say which one is
  about to be annotated;
- the pointer becomes a hand, through a constructed stylesheet adopted for
  as long as the mode lasts (`*{cursor:pointer !important}`) and dropped
  when it ends. A rule over every element is what it takes: a page sets
  cursors on its own elements, and the root's would lose to every one of
  them. A constructed sheet is CSSOM like the rest of the overlay, so it
  is not `style-src`'s business either; where constructed sheets are
  missing the root's cursor is the fallback, and the code checks that the
  sheet was actually kept rather than assuming;
- the next click is taken by a non-passive capturing listener on the
  window, which runs before the bridge's own document listeners, so the
  application does not get the click and neither does the trace;
- the element is described by the same `describe()` every trace event
  uses, plus up to three ancestors and the frame it is in. There is one
  description of a DOM element in Engelbart (`ElementTarget`) and this is
  it;
- `ui.click`, `ui.change` and `ui.keydown` ignore anything inside
  `[data-engelbart]`. `composedPath()` reaches into a shadow root, so
  being in one is no cover; the marked host is.

Nothing here posts to the events endpoint. That endpoint is open to
anyone holding the preview URL; a researcher's words go from the
workspace's own form to a server action over the signed-in session, and
nowhere else. What crosses the picker's channel is a description of an
element — never a note, a user, a project or a run.

Saved notes are found again with `resolveAnchor`: a test id, then a stable
id, then the stored selector (whose `host >>> rest` hops are resolved one
root at a time, because that is not a `querySelector` string), and only
then a search by tag, role, text and ancestors. Screen position is never
identity. The answer is `resolved`, `approximate` — one clear best match,
but something about it has changed — or `unresolved`, which draws no
marker: a marker on a guess would be a lie about where the note belongs.

### The survey

The same channel carries two more messages besides the picker's `mode`,
`show` and `flash`. `survey` is the quietest thing the workspace does to
a page: it asks a document what it holds, and the document answers with
`surveyed` and is otherwise unchanged. Nothing is turned on, no listener
is added, no overlay appears, no cursor moves and no trace event is
recorded — the down-message handling was never gated on the picker being
on, which is what makes this possible without a second channel.

`record` is the other, and it is deliberately not silent: it starts or
stops replay capture and emits an ordinary `frame.record` at both ends,
so the browser's rrweb clock and the sandbox's clock have a pin between
them. It is also the one down-message not passed to child frames — the
recorder walks same-origin frames from the top document, so a child
starting its own would photograph the same screen twice.

What comes back is the reduced page: every element `meaningfulElement`
accepts, minus Engelbart's own and minus anything the document says is
hidden, described by the same `describe()` as everything else and with
`rect` and `route` dropped — where an element sat says nothing about what
it is. `meaningfulElement` accepts a landmark, a role, a label, a good
id, a class worth keeping — and an element that holds a fair amount of
text of its own with few element children, none of which holds nearly
all of it. That last rule is what makes a conversation visible: most
applications render their content as plain `<div>`s with utility
classes, and without it a tutor's whole transcript reaches the survey as
one flattened string inside `<main>`, with no element to attach it to. Each carries an ordinal and the ordinal of the nearest candidate
above it, which is the only handle that leaves the page. Three caps hold
it: 120 candidates, 4000 elements looked at, 96 KB on the wire, and the
answer says when it was cut.

The value of a text field is never in it. `describe()` does not carry
one, and the survey adds nothing `describe()` did not produce.

The workspace asks each time the preview loads, three times over five
seconds, because a bridge in an embedded frame arrives after the one in
the top document — and again whenever the run records a `frame.attached`
or a `ui.route`. A preview is not one interface: the frame holding an
artifact's output often attaches only when somebody opens the tab it is
on, minutes after the page settled, and a screen that replaces another
is a different interface at the same frame. A document that answers
twice is no trouble: the workspace reads an interface once, keyed on its
frame path and route.

## Environment

| variable | process | meaning |
|----------|---------|---------|
| `ENGELBART_TRACE_TOKEN` | model gateway | required; part of the gateway's URL |
| `ENGELBART_TRACE_CAPTURE` | model gateway | `full` (default) or `metadata`. The runtime sets it on the preview gateway too, which ignores it: that one never reads bodies in either mode |
| `ENGELBART_MODEL_GATEWAY_PORT`, `_BIND` | model gateway | default 43200 on 127.0.0.1 |
| `ENGELBART_MODEL_UPSTREAMS` | model gateway | extra hosts to read as model endpoints (does not gate relaying) |
| `ENGELBART_MODEL_DENY` | model gateway | hosts to refuse outright; empty by default |
| `ENGELBART_MODEL_CAPTURE` | preload | the gateway's URL; its presence is what arms the preload |
| `ENGELBART_MODEL_CAPTURE_LOCAL` | preload | local hosts to capture anyway (a fixture upstream in a test) |
| `ENGELBART_TRACE` | hc wrapper | must be exactly `1`, or neither instrumentation nor model capture is attempted |
| `ENGELBART_MODEL_GATEWAY_URL` | hc wrapper | the gateway: it becomes the `ENGELBART_MODEL_CAPTURE` launch marker that arms the preload, and is where capability states are posted |
| `ENGELBART_INSTRUMENTATION` | hc wrapper | `off`/`none`/`0` skips the repository's registered sandbox-only patch and reports `instrument.none` |
| `ENGELBART_INSTRUMENTATION_DIR` | hc wrapper | the registry; `/opt/engelbart/instrumentation` by default |
| `ENGELBART_PRELOAD` | hc wrapper | where the preload lives; `/opt/engelbart/trace/preload.cjs` by default, and a missing file is reported as `instrumentation_failed` |
| `ENGELBART_REDACT_FILE` | both gateways | JSON of values to redact; deleted once read |
| `ENGELBART_PREVIEW_BIND` | preview gateway | default 0.0.0.0 (the public port) |
| `ENGELBART_BRIDGE_FILE`, `ENGELBART_BRIDGE_CONFIG` | preview gateway | the bridge to serve; tuning for it |
| `ENGELBART_RECORDER_FILE` | preview gateway | the replay recorder served at `/__engelbart/recorder.js`; `rrweb-record.js` beside the gateway by default. Optional: with no readable file the gateway says so, answers 404 there, leaves the script out of the injection and reports `recorder: false`, so an older image still serves a working bridge |
| `ENGELBART_WORKSPACE_ORIGIN` | the worker | the origins allowed to turn annotate mode on in a preview and to start a recording there — both ride the one channel. One origin or a comma-separated list, most-used first, because a sandbox from an older image reads only the first. Defaults to `https://$VERCEL_PROJECT_PRODUCTION_URL`, else `https://$VERCEL_URL`, else `http://localhost:3000`. Passed to the preview gateway as `ENGELBART_BRIDGE_CONFIG`'s `parentOrigins`, with `parentOrigin` beside it for an older bridge. An entry that is not a URL is left out; explicitly blank is how you spell no channel at all |

## The Visualizer

`lib/trace/timeline.ts` turns the rows into what the tab shows. Rows: one
per interaction with the requests tied to it, the model calls joined
through those requests and the visible changes attributed to it; runs of
keys in one frame folded into a group (every press counted, folded
repeats included); one per model call; one per request nothing claimed;
one per note. Stages, built on the rows: a stretch of clicks and keys in
one document is "Explored <frame>"; a submit-like act (a form submit,
Enter on a text field, a submit button) that sent something is
"Submitted …", with the click into the field and the move into the frame
just before it; a model call is its own stage; changes with text that
appeared after the call, attributed to the same act, are "Response
appeared". Each stage names the model call it is about, if any: its own,
the first tied to the submit, the last before the response. Gateway
startup, documents and frames, requests no interaction claimed and
rerenders (text removed and put back, no text changed) are grouped as
diagnostics. They are still derived and still reach Bart's tools;
nothing draws them any more — the fold-out Diagnostics bar along the
bottom of the canvas was removed (`behavior-trace.tsx`), so capture
mode, the gateways, the bridge, the instrumentation diff and the rows no
stage claimed are facts on the wire rather than a panel.

Above the canvas are the run banners (`components/trace/run-header.tsx`)
and, if there is one, the error line. Over it: two boxes pinned to the
top right — the Human/Agent side switches, and Clear canvas, which
becomes "Showing from <clock>" with "Show all" beside it once a mark is
set (on a narrow column `flex-wrap` drops the second box under the
first, and the clock span itself is hidden below `sm`) — the zoom and
fit controls in the bottom left, and Bart's small window in the bottom
right. All of them float, taking no height from the canvas. Under it,
and only while a moment's details are open, is the drawer.

The tab is one canvas (`components/trace/trace-canvas.tsx`, drawn with
React Flow; positions come from `lib/trace/layout.ts`). Nothing can be
wired or edited and a card is not selectable as React Flow means it, but
cards can be dragged: one that a person picks up overrules the layout
for itself alone, and a "Put the cards back where the layout had them"
control appears in the corner toolbar once any has been moved. The line
is drawn from the activity graph (`lib/activity/graph.ts`, `graphOf`)
rather than from the stage list, so the two do not correspond one to
one: a submit becomes two cards, the composing and the send; a response
stage becomes a card per named channel; an episode with nothing to show
becomes none. Cards sit left to right in time order, all one width,
joined by a line that says only "then"; a pause longer than half a
second is written on it. What a person did is a light card with a pointer
("Human"), a model call is the one dark card ("Model"), what appeared on
screen is a dashed card with an eye ("Observed"). Compact, a card says
its short title and one thing more (`lib/trace/moments.ts`): how long
the exploring took, the text the page echoed after a submit, a call's
latency and whether it streamed, or that it is still streaming. The
selected card is ringed and says one line more (the keys as glyphs with
counts, a call's status and sizes, the first text that appeared);
nothing else on the line moves. Every card also carries a native
`title` (`components/trace/nodes.tsx`): on a person's card the Activity
reading and where it came from, on a model or observed card the stage
label. Everything else about a moment is read in the drawer under the
canvas. The latest model call is selected until a card is chosen.

The selected moment's details are `event-details.tsx` for a human or
observed moment and `model-call-inspector.tsx` for a call, wrapped by
`DrawerBody` (`components/trace/trace-drawer.tsx`). The trace stands in
the right-hand panel, where there is no width to give away, so they are
a resizable drawer under the canvas rather than a column beside it.
There is no closed state and no bar: choosing a card selects it and
opens its details in the one action, and the drawer is in the tree only
while it is open, closed from inside itself. A card's context or output
node opens it at the matching pane, and a call's panes scroll sideways
rather than wrap, because the panel can be dragged narrow. Its header
carries "Ask Bart", which opens the window in the corner of the canvas
with the cursor in it; the same header is the model-call inspector's
(`event-details.tsx` exports it to both). The trace
is read once, by `hooks/use-trace-view.ts` in the shell, and that one
read feeds the canvas, Activity, Setup's **Events** and Bart alike —
Replay is not among them, because it plays a recording's rrweb stream
rather than reading the trace; the selection lives in
`hooks/use-trace-selection.ts` (`lib/trace/selection.ts`: a stage id, or
a call id with a pane) and resets when the run changes.

- Inspect reads at three levels. For a human or observed moment
  (`components/trace/event-details.tsx`): the title, the time and the
  duration; the text the page echoed after a submit, marked as observed
  after the submit and never as typed text; the acts by name (clicks by
  their target, keys by name and count); the frame it happened in; the
  model call it is tied to, with the call's state and the correlation
  tag. Everything that rests on ("Show evidence"): the full label, the
  tie in the trace's own words, the frame's path, the rows and the raw
  events. For a model call, the Overview says the model, the latency
  and whether it streamed, the message count, the request and response
  sizes, the submit it was joined to with the correlation, and the
  status; provider and path, first byte and first token, usage, chunks,
  capture mode, ids and the headers wait under "Technical details". The
  Context, Messages, Tools, Output and Raw panes are unchanged.
- The Live preview is the running application and nothing else. It kept
  a strip along its bottom naming the last moment, with the list of them
  folded behind it, and that is gone: the trace is the Visualizer, and
  the two now stand side by side rather than one inside the other.
  `components/trace/live-strip.tsx` was deleted; `live-trace.tsx` is
  still in the tree and nothing imports it.
- "Ask Bart" on a moment brings Bart's input into focus with that moment
  as what "this" means: a "Looking at" line above the input, removable.
  It hands the moment over; it asks nothing and analyzes nothing by
  itself.
- There are two tab bars and a surface belongs to one of them for good
  (`lib/workspace-slots.ts`, pure and tested). The middle holds the work
  — the README, the Code, the Live preview and Setup; the right-hand
  panel (`components/center-panel.tsx`) holds five companion tools with
  one job each, in this order — Bart, the Visualizer, Replay,
  Annotations and Activity. None of them nests another. Nothing moves
  between them, so the trace can always be watched growing while the
  application is used beside it.

  The Terminal is not among them. A shell is not a companion to the work
  the way the other five are — they are readings of a run, made after the
  fact and beside whatever you are doing, and typing into the sandbox is
  doing something to the machine — so it is a section of Setup, in the
  middle bar, with the other controls over the sandbox. What the run
  printed is Setup's **Logs** rather than the shell's scrollback, for the
  same reason in reverse: reading a build that failed is looking
  something up about the past, and the two shared a narrow column badly.

  Setup (`components/setup-panel.tsx`) is five sections in one row, with
  a rule falling before Build. To the left of it are the things you do to
  the machine: **Environment**, what the repository is given to run with
  (`components/env-panel.tsx`; with no list to show it says only that the
  variables have not been read yet, because a repository whose scan has
  not run is not a repository that reads nothing), and **Terminal**, a
  prompt in the sandbox. To the right are the things you read about it,
  one question — why is the application in the state it is in — at three
  removes. **Build** is what the pipeline did, the same step list the
  Live preview shows while preparing. **Logs** is the same thing in the
  words the tools themselves used, which is where a step that says only
  "failed" has to be read (`components/run-log.tsx`). **Events** is what
  somebody did to it once it was up: every act on the page in order, each
  leading with what the semantic layer called the element and keeping
  what the page actually held in the parenthesis, so a label that is
  wrong is obvious rather than convincing
  (`components/interface-history.tsx`). `interface-readings.tsx` is no
  longer drawn anywhere — the readings themselves still run, and still
  name the elements in Events and on the canvas; only the list of them is
  gone.

  The Visualizer's tab key is `trace`: it draws the behavior trace, which
  is what everything under `lib/trace` is called, and renaming the key
  would only move the mismatch into every remembered layout.

  The panel shows one of its five at a time. The ones behind are hidden
  rather than unmounted, because most of them lose something real when
  their subtree goes: the Visualizer would forget its camera and its
  selection, and Replay would come back at the start with its stream to
  fetch again. Hidden is `display: none`, which was measured rather than
  assumed — React Flow declines to measure a container that fails
  `checkVisibility()` and keeps the size it had. The middle hides its
  surfaces the same way, and the same measurement covers the shell:
  xterm's fit addon does nothing on a box of no size, so cols, rows and
  scrollback survive the round trip. A pane is mounted the first time it
  is asked for and never while the panel is closed, because a first mount
  in a hidden subtree has no box to measure. The middle mounts its
  surfaces up front except Setup, which waits, because mounting the shell
  opens one in the sandbox and opening a repository is not asking for
  that. The whole panel puts away to a rail, and closing it hides the
  panes rather than dropping them. Which of the five is in front is
  remembered per repository alongside the middle tab; a remembered Trace
  is read forward into the panel, and a remembered Terminal or
  Environment into Setup, rather than being lost.

- A selected model call also shows its branches: cards for what the
  captured request carried (`lib/trace/context.ts`), stacked above and
  to its left and feeding it, and the output it produced hanging below
  it. The cards are a presentation of the message array as sent: system
  instructions, prior conversation, the latest input, tools offered, the
  output contract. Only what the request contained gets a card; nothing
  is inferred about where any of it came from. The system prompt is shown
  in sections only where the prompt itself draws a rule or a heading,
  titled from its own labels, for reading; the text is unchanged. One
  call's branches at a time, so a long run stays flat.
- A branch edge means "this was in the request" or "the model produced
  this", nothing else. The line between cards has no arrowheads: its
  order is time. What appeared on screen is never a node of a call's
  graph.
- A tie the trace recorded is drawn for the selected card only, as an
  arc over the line: a submit to the model call joined to it through its
  requests, a response to the call the same act was still waiting on.
  Solid with an arrowhead, "linked", when an id carried the join; dotted
  without one, "by timing", when only timing did. A submit no call was
  joined to, and a response the trace did not attribute, get no arc;
  nothing is tied to the nearest call for being near. The card at the
  other end is marked as related.
- The text on a submit card is what the page showed right after the
  submit, before its first model call, not what was typed: typed
  characters are never recorded. The inspector says so under the quote
  ("Observed in the page after the submit · typed text is never
  recorded").
- Pan by dragging or scrolling, zoom by pinching; the controls in the
  bottom-left corner zoom in and out, fit the whole trace, return to the
  selected moment, toggle following (which keeps the newest moment in
  frame as it arrives, and switches itself off on any hand pan or pinch),
  and, once a card has been dragged, put the cards back where the layout
  had them. The camera
  moves on its own only when the selected moment and its graph are out of
  view, or when the canvas itself changes size: it slides just far enough,
  or, if they cannot fit at the current zoom, pulls back just enough. A
  pull-back remembers the zoom it left and returns there once a panel
  closes and there is room again; your own pan or zoom lets that go.
- A node opens the call in the drawer at the matching pane.
  The Context pane holds the same decomposition; the Messages and Raw
  panes hold the literal payload, which stays the source of truth.
- What the run recorded and in what mode, the gateways and the bridge,
  the instrumentation applied in the sandbox with its diff, and the rows
  no stage claims are all still derived, and none of them is drawn: the
  Diagnostics bar under the canvas was removed. They reach a person
  through Bart's tools, which read the same grouped trace.

How things are tied together, and what the tab says about it:

- A request carrying `x-engelbart-interaction` is tied to that interaction
  (`explicit`, tagged "linked").
- An API call or server action started within 3 s of an interaction and
  carrying no id is tied to the latest interaction before it, marked
  `temporal` (tagged "temporal"; the tag's tooltip and the stage's detail
  carry the delay and the evidence).
- A model call is tied to the one application request in flight when it
  began (the collector's join, always by timing), and through it to the
  request's interaction.
- A `ui.change` is tied to the latest interaction the bridge knew of
  (by timing).

Nothing in these labels comes from knowledge of a particular application:
frames are named by their name attribute, a single identifier-like query
value, a unique title, their path and query, or their place in the parent
(the rest stays in the details); acts by their tag, text, label or
placeholder.

## Recordings

A recording is a slice of a run's trace between two clock readings, saved
on purpose. It is one row (`engelbart_recordings`: run, project, name,
status, `started_at`, `stopped_at`, `created_at`, `replay_path`;
migrations `20260920120000_recordings.sql` and
`20260923100000_recording_replay.sql`) and, in the trace, nothing else:
no trace event and no model call is copied, and none carries a recording
id. The pictures rrweb took are a file under `replay_path`, which is the
one thing a recording does hold beyond its boundaries. The trace is
captured whether or not anything is being recorded; a recording only
marks where a stretch of it begins and ends.

"● Record" sits in the Live preview's header
(`components/trace/record-control.tsx`). Pressing it writes the row and
starts the clock on the button; "Stop" writes the other boundary and
leaves one line above the preview saying what was saved, with a way to
open it. Neither touches the sandbox or the run. They do reach the page
in the frame: Record posts `{type:"record", on:true}` into the preview
over the origin-pinned channel — twice, in case the bridge is not
listening yet — and the bridge streams rrweb parts back; Stop posts
`{on:false}`. That is capture of the pictures, not of the trace, which
runs whether or not anything is being recorded.
One recording is open at a time per run: a partial unique index enforces
it in the database, the hook returns the open one rather than starting a
second, and a reload finds it again instead of duplicating it
(`hooks/use-recordings.ts`, `app/workspace/[workspaceId]/recording-actions.ts`).
Stop is also on the recording's row in the Replay list, because the Live
preview's button goes away when the run ends and a recording must never
be left with no way to close it. The write
policies bind a recording to its run's own project, so the one-at-a-time
slot on a run cannot be taken from another project.

Recordings are the Replay tab (`components/trace/replay-panel.tsx`).
One row shape for every recording the repository has, grouped by run:
newest run first, the recordings inside a run in the order they were
made, each run said once at the head of its group as its start time
alone with a count of its recordings beside it. What became of the run
is not said there: its status was, for a while, and it is the same word
in a smaller place — a group headed "Failed" reads as a group of failed
recordings. That belongs to the run, and is in Build, on the step it
happened on. The row under it says only what is true of a recording:
what it is called and how long it lasted, and its own state only when
there is nothing to watch ("No replay saved"). There used to be
two shapes — a card for the open run's recordings carrying what each
holds, a line for the rest — and that split was not emphasis but a
confession, because the counts can only be derived against the trace of
the run being read and the other runs' recordings could never have them.
So the row says only what is true of all of them; the counts live where
they can be had, in the line the Live preview shows when a recording is
saved. Renaming and
deleting are the open run's own actions and are offered on its rows only;
deleting removes the boundaries, never the trace under them. Opening one
plays its rrweb stream there (`replay-surface.tsx`) and cuts Activity and
the Visualizer to the same minutes — they say so in a line above the
canvas, with the way back to the whole run. Nothing else changes: the
same canvas, the same drawer, the same inspector and the same selection,
with only the data scope moved:
`lib/trace/recording.ts` cuts the run's events and calls to the window
and `useScopedTraceView` re-derives rows, stages and calls from them with
the existing functions, passing the whole run's frame index so documents
named before the slice keep their names. A model call belongs to a
recording by when it started, and comes whole even if it was still
answering at Stop, because every event carrying its id follows it; an
event that happened after Stop does not. A call that began before Record
is not in it at all. The counts in the list are derived the same way, not
stored, and they are shown in the "Recording saved" line above the Live
preview rather than in the list — the only place they can be had, since
they are derived against the trace of the run being read. A moment
chosen from outside the open recording — now only a reference in one of
Bart's answers, the preview's strip being gone — closes the recording
and shows the whole run, rather than being ringed where it cannot be
seen. What the canvas is cut to is said by a banner above it
(`RunBanners`, `components/trace/run-header.tsx`): "Cut to “<name>”, the
recording open in Replay", with a "Whole run" button that clears it.

Over the full trace the corner box on the canvas also carries "Clear
canvas" (`components/trace/behavior-trace.tsx`). It hides what came before and
deletes nothing: the mark it takes is a reading of the trace's own clock
(`clearMark` in `lib/trace/recording.ts` — the latest `at` of the rows,
a millisecond on, because events carry the sandbox's clock and the
browser's is a different one, and because a window includes its start)
and it is shown through the same `scopeTrace` window a recording is,
rather than a second way of cutting the canvas down. Collection carries
on, the rows stay, every saved recording still holds what it held, and
the notes are untouched; that same box swaps the button for "Showing
from …" with "Show all" beside it — on a narrow panel the clock is
dropped and only "Show all" is left — and the canvas gets a new key so it frames what it now holds
instead of keeping a camera pointed at moments that are no longer drawn.
The selection is dropped with the clear, so "this" in the conversation
is never a moment that has left the canvas. The mark belongs to the run:
it survives moving between tabs and goes when the run does. A recording
started after a clear begins at its own Record and so appears on the
same clean canvas. Bart is not told about a clear at all — it is a way
of looking, not a fact about the session, and the run is what was
recorded.

Bart is told the recording's id, never its contents. While one is open,
its trace tools read the same slice by default and the situation block
lists the recording's moments instead of the run's, so "what did I do in
this recording" and "why did this happen" resolve inside it; a tool can
ask for `scope: "run"` to see the whole run, and the repository, the
README and the source are never scoped. The panel shows which recording
is in scope above its input.

## What the interface is for

The trace can say `“Submit” (button) in embedded frame “solution”`. It
cannot say that the embedded document is the game the tutor generated,
that a textarea is where a student answers, or that a column of divs is a
conversation. A **semantic map** is one model's answer to that question
about one document, made once and then cached (`lib/semantics/`).

Three rules hold it together, and everything else follows from them.

The question it answers is a researcher's first one. They have opened
somebody else's software, they did not write it and have not read its
source, and they are looking at a screen they have never seen. So a
reading carries a **purpose** as well as names: one or two sentences on
what this interface lets a person do, and where. Of the interface, from
the interface — never what the person using it wants, believes or found,
which is the line the plan drew and this does not cross.

*A label never replaces evidence.* Every named thing carries the
`ElementTarget`s it was derived from, stored verbatim as the page
described them. `describeTarget(d, match)` puts the name in front and the
raw description inside the parenthesis — `Generate game (“Submit”
button)` — and a match the reader was unsure of is not shown at all, so
the raw description keeps the front of the line. Nothing joins a semantic
id to a trace row in the database; the rows are named at `traceRows` time
the way a frame's name is, and a run with no reading is the run it always
was.

*There is no second targeting system.* A semantic node identifies its
elements by the same `ElementTarget` the trace and the notes use. Nothing
in `lib/semantics/` builds a selector or reads a DOM.

*The model never names an element itself.* It is shown numbered lines
with no selector in them — putting one in front of a model only invites
it to write one back — and answers through a forced tool whose schema has
no free-text field that goes anywhere. `readSemanticMap` then resolves
the ordinals against the survey and **drops any node whose ordinals
resolve to nothing**. A model cannot point at an element nobody offered.
The element list is declared to it as data, and the page's own text is
treated as text on a page whatever it says.

### The signature

A reading is cached on `(repo_id, signature)`. Not on the run — a
document read yesterday is the same document today, which is the point.
Not on the commit sha either: that is read at clone time, before the
repair patch and the sandbox-only instrumentation are applied, so two
runs on one sha can serve different documents. The sha is kept as context
and never as identity.

The signature is a hash of the survey under a policy
(`lib/semantics/signature.ts`), and the policy is a deliberately tunable
heuristic, not an invariant:

| knob | default | what it decides |
|---|---|---|
| `namingText` | `controls` | whose words are a name. A control's text is its name; a heading's names the area under it; a paragraph's is content. `all` invalidates on every message; `none` misses a renamed button. |
| `repeats` | `fold` | whether **how many** alike parts there are is part of the interface. Folded, a list of three and a list of four are one interface. |
| `structure` | `true` | whether where a candidate sits counts. It is said as what the parent **is**, never as the ordinal the parent was given, or inserting one list item would change every part below it. |
| `selectorValue` | `false` | whether the selector's value counts, not merely that there is one. |

A document's `<title>` is a hint and is treated as one: the framework
defaults (`Create Next App`, `React App`, `Vite + React`, `Document`, …)
are never shown to the reader at all, and a `documentLabel` that comes
back word-for-word as the title is demoted to low confidence, because
naming a document after its own title is transcription rather than
reading. ROPE's first reading came back as "Create Next App" with high
confidence for exactly this reason.

`diffSignature` / `sayDiff` say what moved, so a miss is explained rather
than asserted, and `scripts/semantics/verify.mts` is how the defaults
were arrived at: it runs this bridge in a jsdom document on its own
origin, surveys it over the real channel, signs it, applies the changes a
running application makes to itself (a rerender, a new list item, text
replacing a placeholder, a control disabled, a control renamed, a whole
screen swapped) and reports whether the signature held or moved. Two of
the defaults above are corrections it found.

### Finding a name again

A reading may stand in for a placeholder and never for evidence. On a
row's chip, "the page" says only that this is the top document, so a
confident reading replaces it; a frame the DOM named "solution" keeps
that name and the reading joins it — `Solution game (solution)`.

`lookupTarget` climbs the same ladder `resolveAnchor` does, for the same
reason: a test id, then an id, then the selector, then the shape of the
thing. **Two named things sharing a handle yields nothing** — half a
label is worse than none. A document is matched by the chain of
`<iframe>`s it sits inside, never by a frame id, which is minted per
served document and is gone on the next reload.

### Where it shows

Nowhere, as a list. The readings are drawn into the things they name —
the chips on a trace row, the cards on the canvas, the acts in Setup's
**Events** — and the list of them with their signatures and their
provenance, which was a view inside the old Trace tab, is not mounted
anywhere at HEAD. `components/trace/interface-readings.tsx` is still in
the tree, with its **Read again** control, and nothing imports it.
Whether a document's answer came from the database or from a model, and
what moved when it did not, is therefore a thing the code knows and the
interface does not say.

Bart gets `inspect_ui_semantics`, and is told plainly that this is the
one source that is not evidence: a reading of a page, to be used for the
application's own words and never as proof that something happened.

## Bart

Bart is the first tab of the right panel, which it shares with the
Visualizer, Replay, Annotations and Activity, and a small window in the
corner of the Visualizer's canvas (`components/trace/trace-bart.tsx`). Both are views of one
conversation: `hooks/use-bart-session.ts` holds it for the workspace, so
a question asked beside the evidence is in the panel when you get there
and a half-typed one survives the walk between them. Bart is not in the
middle tab bar, and nothing under the trace canvas is reserved for a
chat. The two surfaces share their parts
(`components/bart/conversation.tsx`, `components/bart/composer.tsx`);
`components/bart-panel.tsx` is the panel, and the window over the canvas
is the same pieces drawn compactly, floating, so opening, closing and
resizing it move neither the canvas nor its camera. That window scrolls
its conversation, sends from its own composer, and is dragged bigger or
smaller from its top-left corner (arrow keys too, once the grip has
focus); it is pinned to the bottom-right, never grows past the canvas,
and the size it was left at is remembered in the browser. It offers
what the selection is ("Ask Bart about this model call…", from
`askPlaceholder` in `lib/bart/labels.ts`), and "Ask Bart" — in the
drawer's header, which the model-call inspector shares — opens it with
the cursor in it. Its panel button hands the same thread to the right
panel. What travels with a question is identity, and two things that are
not: the run, the repository, the selected stage or call, the open
recording and the open note, plus the answering options set in the
composer (effort, temperature, the token ceiling) and any attached text
files. `lib/bart/options.ts` holds both, pure and tested, and the route
clamps what it is given rather than trusting it; attachments are capped
at five files, 60,000 characters each and 150,000 in all, and are folded
into the message body on the server. It answers
from four sources through tools, never from a dump of them: the trace,
the captured model calls, the repository, and the notes a researcher
wrote on the running interface. `app/api/bart/route.ts` takes
a question with what is in the middle named by id (project, repository,
run, selected moment), writes a short situation (`lib/bart/prompt.ts`:
the repository and where its source can be read, the run and its capture
mode, a line naming the open recording and saying that the moments and
the trace tools are scoped to it, a line naming the open note and
pointing at `inspect_annotation`, the selected moment, one line per
moment of the run with its id and the tie the trace recorded, and, over
the same stretch, the reading of what the person was doing) and lets the model fetch with `lib/bart/tools.ts`:
`run_overview`, `inspect_moment`, `inspect_model_call` (a part at a
time: summary, the system prompt in the sections it marks, messages,
tools, output, settings, raw bodies; long parts are cut with an offset
to continue), `compare_model_calls` (the differences computed, not
narrated), `search_trace`, `read_readme`, `repo_tree`, `read_repo_file`,
`search_repo`, `list_annotations` and `inspect_annotation`. The trace tools are `lib/bart/grounding.ts`, the
same derivations the tab shows written as text that names things by id
and says how a tie was made ("by an id the request carried" or "by
timing; an association, not proof"); the echo after a submit is marked
as what the page showed, never as typed text. The repository tools
(`lib/bart/repo.ts`) read the live sandbox first (`git ls-files`, the
file, `git grep -F -i`) and GitHub when the run is down (for search, a
bounded read of the likeliest source files, and the answer says so);
environment files and keys are never read, and the repository's saved
environment values are struck from anything returned. The answer
streams as server-sent events along with the tools it runs; tool output
is data to the model, never instructions, and the prompt says so.

The two annotation tools are `lib/bart/annotations.ts`.
`list_annotations` is the way in: one line a note, with its id, the
element it is on, the route, and an excerpt of what was written, so
"what have I noted here?" has ids to work from without one being open.
The list is the repository's, because a note outlives the run that made
it; which run or recording each was written in is marked rather than
filtered, since "what did I note in this session" and "what have I ever
noted here" are both questions. The excerpt is deliberate: a note runs to
4000 characters and a tool answer is cut at 12,000, so the list stays a
way of choosing and `inspect_annotation` is how one is read in full.
That report keeps what the researcher wrote apart from what the DOM held,
names the run, recording and commit as where it came from, and offers
moments recorded near it as timing and nothing more. The read policy is
the project's, so `app/api/bart/route.ts` filters by repository itself:
a project holds several artifacts and a listing that forgot would answer
with another one's notes. Both reads are then checked against the open
repository, and the query error is kept rather than dropped, so an
unapplied migration reads as what it is instead of as a repository
nobody has annotated.

An answer cites with tokens (`lib/bart/protocol.ts`):
`[[moment:<stage id>]]`, `[[call:<call id>:<pane>]]`,
`[[file:<path>#L<from>-L<to>]]`, `[[readme]]`, `[[annotation:<id>]]`. The panel renders them as
chips (`components/bart-markdown.tsx`) labelled from the trace
(`lib/bart/labels.ts`, except an annotation chip, which is labelled from
the note's own words cut to forty characters); a chip opens the moment
or the call in the Visualizer with the drawer on it, the file in the
Code tab, the README, or — for a note — the Live preview, with the note
in focus where it was written. The provenance categories (trace, captured request, source,
inferred) live in the tool text and the references; Bart is asked to
write naturally, to say "the trace shows" or "I would infer" where it
matters, and never to present a temporal tie as a cause.

Conversations persist per workspace in `engelbart_bart_threads` and
`engelbart_bart_messages` (migration `20260920100000_bart_threads.sql`;
row-level security through the project, like the repositories; each
user message keeps the run, repository and selection it was asked with,
so a thread can later span runs). `lib/bart/store.ts` reads and writes
them, `bart-actions.ts` loads the latest thread on arrival and starts a
new one on Clear, `hooks/use-bart.ts` streams a turn. The models Bart
can use are one list, `lib/bart/models.ts`, shown in the panel's picker
and checked by the route; the server reads `ANTHROPIC_API_KEY`. Under
the input there is only the toolbar: attach, the answering options, the
model, and Send — Stop while a turn is streaming.

## Tests

`npm test` is `node --import tsx --test 'tests/**/*.test.*'`: everything
under `tests/`, not only the trace. Of that, `tests/trace/` is the
gateways against fixture upstreams, the bridge in jsdom, annotate mode in
a framed jsdom document served on its own origin (the origin is the whole
question, and jsdom gives a blank frame an opaque one), the collector
against a fake database, and the timeline model. Annotations themselves
are under `tests/annotations/` and `tests/bart/annotations.test.mts`, and
the semantic layer under `tests/semantics/` — the vocabulary and the two
untrusted boundaries (a survey from a page, a reading from a model), the
lookup ladder, the signature policy, what the model is shown, and what a
trace row says with and without a reading. `tests/activity/` holds the
reading of what a person was doing, and `tests/workspace/` the pure parts
of the shell the trace is read in: the slot algebra of the two tab bars,
the environment's pending values, the run's steps, the code file list and
the sidebar's width. Model capture has five suites: `tests/trace/preload.test.mjs`
runs each hook in a real child process under the real preload, and
`tests/sandbox/` holds three — `hc-instrumentation.test.mjs` drives hc's
capability module through `python3` (which launchers may take a preload,
which are refused, and that a repository can neither choose the path nor
reach the marker), `instrumentation-registry.test.mjs` holds the registry
of sandbox-only edits and why it is now empty, and
`edge-detection.test.mjs` what the wrapper makes of middleware.

What `npm test` cannot do is run a real page or a real artifact.
`npm run semantics:verify -- <file-or-url>` does the first, and with
`ANTHROPIC_API_KEY` set it reads the page for real. `npm run capture:check`
does the second: it clones a pristine research artifact, runs its own
model call under the preload, and checks nineteen things about the result,
including that the repository is byte-for-byte unchanged. `npm run
capture:coverage` measures which runtimes and launchers capture reaches
and prints the table in [CAPTURE.md](CAPTURE.md). The events endpoint is as public as the
preview itself; it can only add events to the run whose gateway received
them, never read anything.
